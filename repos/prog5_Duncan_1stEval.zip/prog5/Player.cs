﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Mankalah
{
   /*****************************************************************
    * A Mankalah player.  This is the base class for players.
    * You'll derive a player from this base. Be sure your player
    * works correctly both as TOP and as BOTTOM.
    *****************************************************************/
    public abstract class Player
    {
        private String name;
        private Position position;
        private int timePerMove;	// time allowed per move in msec

        /*
         * constructor. Parameters are position (TOP/BOTTOM) the player
         * is to play, the player's name, and maxTimePerMove--the time
         * your player is allowed to use per move, in milliseconds. 
         * (This is not enforced, but your player will be disqualified 
         * if it takes too long.) If you have any tasks to do before 
         * play begins, you can override this constructor.
         */
        public Player(Position pos, String n, int maxTimePerMove)
        {
            name = n;
            position = pos;
	        timePerMove = maxTimePerMove;
            Console.Write("Player " + name + " playing on ");
            if (pos == Position.Top) Console.WriteLine("top.");
            if (pos == Position.Bottom) Console.WriteLine("bottom.");
            if (pos != Position.Top && position != Position.Bottom)
            {
                Console.Write("...an illegal side of the board.");
                Environment.Exit(1);
            }

            // Create a dictionary (hash table) of all of the across values
            Dictionary<int, int> across = new Dictionary<int, int>();
            // top                bottom
            across.Add(13, 6); across.Add(6, 13);
            across.Add(12, 0); across.Add(0, 12);
            across.Add(11, 1); across.Add(1, 11);
            across.Add(10, 2); across.Add(2, 10);
            across.Add(9, 3); across.Add(3, 9);
            across.Add(8, 4); across.Add(4, 8);
            across.Add(7, 5); across.Add(5, 7);
        }

        /*
         * Evaluate: return a number saying how much we like this board. 
         * TOP is MAX, so positive scores should be better for TOP.
         * This default just counts the score so far. Override to improve!
         */
        public virtual int evaluate(Board b)
        {
            int result = 0;
            int constReward = 3;  // TODO: play around with

            if (b.whoseMove() == Position.Top) // if it's the top player
            {
                /* Score difference */
                int scoreDiff = b.stonesAt(13) - b.stonesAt(6);
                if ( scoreDiff > 0)  { result += scoreDiff; } // if the difference in score is greater than 0, add it to result 
                else { result -= scoreDiff; }                 // if diff in score less than 0, subtract it from result (bad)

                /* Go-agains */
                // TODO: Try adding a break to try just first go again to speed up, play with it without too
                for (int i = 12; i >= 7; i--)               // add score for go-agains
                    if (b.stonesAt(i) == 13 - i) result += constReward; 
                

                /* Friendly captures */
                for (int i = 12; i >= 7; i--) // if capture is available 
                {
                    if (b.stonesAt(i) == 0 && b.stonesAt(across(i)) > 0) // if there is a possible available capture
                    {
                        for( int j = 12; i >= 7; j--)  // see if we can perform that capture and reward accordingly
                        {
                            if ( j + b.stonesAt(j) == i )
                            {
                                result += (b.stonesAt(across(i)) + constReward); // we can caputre all of the stones across from i
                            }
                        }
                        
                    }
                }

                /* Enemy captures */
                for (int i = 5; i >= 0; i--) // if enemy capture is available
                {
                    if (b.stonesAt(i) == 0 && b.stonesAt(across(i)) > 0) // if there is a possible enemy capture available
                    {
                        for (int j = 5; i >= 0; j--)  // see if they can perform that capture and penalize accordingly
                        {
                            if (j + b.stonesAt(j) == i)
                            {
                                result -= (b.stonesAt(across(i)) - constReward); // they can caputre all of the stones across from i
                            }
                        }

                    }
                }
            }
            else // if it's the bottom player
            {
                constReward *= -1;

                /* Score difference */
                int scoreDiff = b.stonesAt(13) - b.stonesAt(6);
                if (scoreDiff > 0) { result -= scoreDiff; } // if the difference in score is greater than 0, subtract it from result 
                else { result += scoreDiff; }                 // if diff in score less than 0, add it to result (bad)

                /* Go-agains */
                // TODO: Try adding a break to try just first go again to speed up, play with it without too
                for (int i = 5; i >= 0; i--)               // add score for go-agains
                    if (b.stonesAt(i) == 6 - i) result += constReward;

                /* Friendly captures */
                for (int i = 5; i >= 0; i--) // if friendly capture is available
                {
                    if (b.stonesAt(i) == 0 && b.stonesAt(across(i)) > 0) // if there is a possible enemy capture available
                    {
                        for (int j = 5; i >= 0; j--)  // see if we can perform that capture and reward accordingly
                        {
                            if (j + b.stonesAt(j) == i)
                            {
                                result -= (b.stonesAt(across(i)) - constReward); // we can caputre all of the stones across from i
                            }
                        }

                    }
                }

                /* Enemy captures */
                for (int i = 12; i >= 7; i--) // if enemy capture is available 
                {
                    if (b.stonesAt(i) == 0 && b.stonesAt(across(i)) > 0) // if there is a possible available capture
                    {
                        for (int j = 12; i >= 7; j--)  // see if they can perform that capture and penalize accordingly
                        {
                            if (j + b.stonesAt(j) == i)
                            {
                                result += (b.stonesAt(across(i)) + constReward); // they can caputre all of the stones across from i
                            }
                        }

                    }
                } 
            }
            return result;
        }

        public String getName() { return name; }

        public int getTimePerMove() { return timePerMove; }

        /*
         * Provide a photo of yourself (or your avatar) for the
         * tournament. You can return either
         * 1. the url of a photo "http://www.example.com/photo.jpg"
         * 2. the filename of a photo "photo.jpg"
         */
        public virtual String getImage() { return String.Empty; }


        private Tuple<int, int> MiniMax(Board b, int d) // d is depth
        {
            if (b.gameOver() || d == 0)
                return new Tuple(0, evaluate(b));
            if (b.whoseMove() == Position.Top) // MAX
            {
                int bestVal = int.MinValue; // minimum value of integer
                for (int i = 12; i >= 7; i--)
                {
                    if (b.legalMove(i) ) // TODO: && time not expired
                    {
                        Board b1 = new Board(b);      // copy board
                        b1.makeMove(i);               // make move
                        int val = MiniMax(b1, d - 1); // find value
                        if (val > bestVal)            // remember if best
                        {
                            bestVal = val; int bestMove = i;
                        }
                    }
                }
            }
            else // bottom's move (MIN)
            {
                int bestVal = int.MaxValue; // maximum value of integer
                for (int i = 12; i >= 7; i--)
                {
                    if (b.legalMove(i)) // TODO: && time not expired
                    {
                        Board b1 = new Board(b);      // copy board
                        b1.makeMove(i);               // make move
                        int val = MiniMax(b1, d - 1); // find value
                        if (val < bestVal)            // remember if best
                        {
                            bestVal = val; int bestMove = i;
                        }
                    }
                }
            }
            return new Tuple<int, int>(bestMove, bestVal);
        }


        /*
         * Override with your own choosemove function
         * TODO: Put in situations where you don't even need to call evaluate
         */
        public abstract int chooseMove(Board b)
        {
            // implement timer...?
        }

        /*
         * Override with your own personalized gloat.
         */
        public virtual String gloat() { return "I win."; }
    }
}
