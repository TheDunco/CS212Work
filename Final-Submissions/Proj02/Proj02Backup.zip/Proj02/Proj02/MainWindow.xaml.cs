﻿/* Duncan Van Keulen
 * Program 2: Babble Program
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Proj02
{
    /// Babble framework
    /// Starter code for CS212 Babble assignment
    public partial class MainWindow : Window
    {
        private Dictionary<string, List<string>> babbleTable = new Dictionary<string, List<string>>();    // Create a global variable for the hash table
        private string input;               // input file
        private List<string> words;             // input file broken into list of words
        private int wordCount = 200;        // number of words to babble
        private int currentOrder = 1;        // current selected order, set by analyzeInput

        public MainWindow()
        {
            InitializeComponent();
        }

        private void loadButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog ofd = new Microsoft.Win32.OpenFileDialog();
            ofd.FileName = "Sample"; // Default file name
            ofd.DefaultExt = ".txt"; // Default file extension
            ofd.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            // Show open file dialog box
            if ((bool)ofd.ShowDialog())
            {
                textBlock1.Text = "Loading file " + ofd.FileName + "\n";
                input = System.IO.File.ReadAllText(ofd.FileName);  // read file
                words = Regex.Split(input, @"\s+").ToList();       // split into array of words
            }


            fill_Hash_Table(words, 1);
            hash_Dump();
        }
        /* Dump the hash table to the textBlock
         * @void
         * TODO: CHANGE TO MAKE STATISTICS INSTEAD OF DUMPING ENTIRE TABLE (or have it just dump the first couple of keys)
         */
        private void hash_Dump()
        {
            textBlock1.Text = "";   // reset the text block to show nothing
            foreach (KeyValuePair<string, List<string>> entry in babbleTable)
            {
                textBlock1.Text += entry.Key + " -> ";

                foreach (string word in entry.Value)
                {
                    textBlock1.Text += word + " ";
                }
                textBlock1.Text += "\n";
            }
        }

        private void fill_Hash_Table(List<string> strLst, int j)
        {
            babbleTable.Clear();
            // Fill the hash table with the key/value pairs of successive words based on the order selected
            for (int i = 0; i < strLst.Count - j; i++)       // Loop through the whole array...
            {
                string anchor = strLst[i];     // make the first element of the list the "anchor" or first word

                /* For each word in the array, loop through the next words up to the order and concatenate
                 *with dashes until the order */
                for (int k = i + 1; k < j + i; k++)   
                {
                    anchor += "-" + strLst[k];
                }
                if (!babbleTable.ContainsKey(anchor))
                    babbleTable.Add(anchor, new List<string>());
                babbleTable[anchor].Add(strLst[i + j]);
            }
        }

        private void analyzeInput(int order)
        {
            if (order > 0)
            {
                MessageBox.Show("Analyzing at order: " + (order + 1));
                fill_Hash_Table(words, (order + 1));
                hash_Dump();

                currentOrder = (order + 1);     // set the global order variable to the current order

            }
        }

        private void babbleButton_Click(object sender, RoutedEventArgs e)
        {
            textBlock1.Text = "";   // reset the text block to nothing

           // string current = words[0] + '-' + words[1]; // TODO: Change to order -1

            List<string> keyList = words.GetRange(0, currentOrder);

            string keyString = keyList.Aggregate((left, right) => left + " " + right);

            Random rand = new Random();

            textBlock1.Text += keyString + " ";

            //    int next = 0;
            for (int i = 0; i < Math.Min(wordCount, words.Count); i++)
            {

                if (babbleTable.ContainsKey(keyString))
                {
                    /* // works only for first order
                     next = (int)rand.Next(0, babbleTable[current].Count);   // choose the next value randomly from the list of values associated with the key that was previously chosen
                     current = (string)babbleTable[current][next];   // set the current value to the string of the current key and the randomly chosen next word
                     */
                    List<string> nextWordsSelection = babbleTable[keyString];

                    int randomIndex = rand.Next(nextWordsSelection.Count);

                    string nextWord = nextWordsSelection[randomIndex];

                    textBlock1.Text += nextWord + " ";

                    keyList.RemoveAt(0);
                    keyList.Add(nextWord);

                    keyString = keyList.Aggregate((left, right) => left + " " + right);
                }

                else
                {
                    keyList = words.GetRange(0, currentOrder);
                    keyString = keyList.Aggregate((left, right) => left + " " + right);
                }    // if the word is not a key in the list, return to the beginning


            }

        }

        private void orderComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            analyzeInput(orderComboBox.SelectedIndex);
        }
    }
}
