﻿/* Duncan Van Keulen
 * Program 2: Babble Program
 */
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Proj02
{
    /// Babble framework
    /// Starter code for CS212 Babble assignment
    public partial class MainWindow : Window
    {
        private Dictionary<string, List<string>> babbleTable = new Dictionary<string, List<string>>();    // Create a global variable for the hash table
        private string input;               // input file
        private List<string> words;             // input file broken into list of words
        private int wordCount = 200;        // number of words to babble
        private int currentOrder = 1;        // current selected order, set by analyzeInput

        public MainWindow()
        {
            InitializeComponent();
        }

        private void loadButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog ofd = new Microsoft.Win32.OpenFileDialog();
            ofd.FileName = "Sample"; // Default file name
            ofd.DefaultExt = ".txt"; // Default file extension
            ofd.Filter = "Text documents (.txt)|*.txt"; // Filter files by extension

            // Show open file dialog box
            if ((bool)ofd.ShowDialog())
            {
                textBlock1.Text = "Loading file " + ofd.FileName + "\n";
                input = System.IO.File.ReadAllText(ofd.FileName);  // read file
                words = Regex.Split(input, @"\s+").ToList();       // split into array of words
            }


            fill_Hash_Table(words, 1);
            hash_Dump();
        }
        /* Dump the hash table to the textBlock
         * For debugging purposes
         * @void
         * TODO: MAKE STATISTICS FUNCION INSTEAD OF DUMPING ENTIRE TABLE
         */
        private void hash_Dump()
        {
            textBlock1.Text = "";   // reset the text block to show nothing
            foreach (KeyValuePair<string, List<string>> entry in babbleTable)
            {
                textBlock1.Text += entry.Key + " -> ";

                foreach (string word in entry.Value)
                {
                    textBlock1.Text += word + " ";
                }
                textBlock1.Text += "\n";
            }
        }

        private void fill_Hash_Table(List<string> strLst, int j)
        {
            babbleTable.Clear();
            // Fill the hash table with the key/value pairs of successive words based on the order selected
            for (int i = 0; i < strLst.Count - j; i++)       // Loop through the whole array...
            {
                string anchor = strLst[i];     // make the first element of the list the "anchor" or first word

                /* For each word in the array, loop through the next words up to the order and concatenate
                 *with dashes until the order */
                for (int k = i + 1; k < j + i; k++)   
                {
                    anchor += " " + strLst[k];
                }
                if (!babbleTable.ContainsKey(anchor))
                    babbleTable.Add(anchor, new List<string>());
                babbleTable[anchor].Add(strLst[i + j]);
            }
        }

        private void analyzeInput(int order)
        {
            if (order > 0)
            {
                MessageBox.Show("Analyzing at order: " + (order + 1));
                fill_Hash_Table(words, (order + 1));
                hash_Dump();

                currentOrder = (order + 1);     // set the global order variable to the current order

            }
        }

        /* babbleButton_Click handler
         * Handles the babbleButton click and contains babbling algorithm
         * @precondition: File must be loaded
         * @postcondition: textBlock1 will be set to the babbled version of the dictionary based on the current selected order
         */
        private void babbleButton_Click(object sender, RoutedEventArgs e)
        {
            textBlock1.Text = "";                                       // reset the text block to nothing

            List<string> keyList = words.GetRange(0, currentOrder);     // make a list initialized to the first words of the file

            string keyString =                                          // combine the list to make it a string
                keyList.Aggregate((left, right) => left + " " + right);

            Random rand = new Random();                                 // initialize a random object

            textBlock1.Text += keyString + " ";                         // set the textblock to the first words of the file to start

            for (int i = 0; i < Math.Min(wordCount, words.Count); i++)  // loop up to the current word count (init 200)
            {

                if (babbleTable.ContainsKey(keyString))                 // avoid a key not being in the list
                {

                    List<string> nextWordsSelection = babbleTable[keyString];   // make a list of the next words you can choose from

                    int randomIndex = rand.Next(nextWordsSelection.Count);      // choose a random index of that list to become the next word

                    string nextWord = nextWordsSelection[randomIndex];          // select the next word from the list of words based on the random index

                    textBlock1.Text += nextWord + " ";                          // add the next word to the text block

                    keyList.RemoveAt(0);                                        // remove one word from the beginning of the key

                    keyList.Add(nextWord);                                      // add the chosen next word to the key to become the next key

                    keyString =                                                 // combine that new list into a string to be used as the next key
                        keyList.Aggregate((left, right) => left + " " + right);
                }

                else
                {
                    keyList = words.GetRange(0, currentOrder);                  // if the key is not currentlty in the list of keys,
                                                                                // start back at the beginning
                    keyString = keyList.Aggregate((left, right) => left + " " + right);
                } 


            }

        }

        private void orderComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            analyzeInput(orderComboBox.SelectedIndex);
        }
    }
}
